async function searchWord() {
    let word = document.getElementById('word').value;
    let resultDiv = document.getElementById('result');
    if (word === '') {
        resultDiv.innerHTML = '<p>Please enter a word.</p>';
        return;
    }
    
    let url = `https://api.dictionaryapi.dev/api/v2/entries/en/${word}`;
    try {
        let response = await fetch(url);
        let data = await response.json();
        if (data.title) {
            resultDiv.innerHTML = '<p>Word not found. Try another.</p>';
            return;
        }
        
        let meaning = data[0].meanings[0].definitions[0].definition;
        let phonetics = data[0].phonetics[0]?.text || 'N/A';
        
        resultDiv.innerHTML = `
            <h3>${word}</h3>
            <p><strong>Phonetics:</strong> ${phonetics}</p>
            <p><strong>Meaning:</strong> ${meaning}</p>
        `;
    } catch (error) {
        resultDiv.innerHTML = '<p>Error fetching data. Try again later.</p>';
    }
}
```
```