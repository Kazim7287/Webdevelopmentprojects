// Function to generate input fields for marks calculation
function generateMarksInputs() {
    let totalSubjects = document.getElementById("totalSubjects").value;
    let marksInputs = document.getElementById("marksInputs");
    marksInputs.innerHTML = "";

    for (let i = 0; i < totalSubjects; i++) {
        marksInputs.innerHTML += `
            <h4>Subject ${i + 1}</h4>
            <input type="number" id="totalMarks${i}" placeholder="Total Marks for Subject ${i + 1}" />
            <input type="number" id="obtainedMarks${i}" placeholder="Obtained Marks for Subject ${i + 1}" />
        `;
    }
}

// Function to calculate total percentage and grade
function calculateTotalPercentage() {
    let totalSubjects = document.getElementById("totalSubjects").value;
    let totalMarksSum = 0, obtainedMarksSum = 0;

    for (let i = 0; i < totalSubjects; i++) {
        let totalMarks = parseFloat(document.getElementById(`totalMarks${i}`).value) || 0;
        let obtainedMarks = parseFloat(document.getElementById(`obtainedMarks${i}`).value) || 0;

        totalMarksSum += totalMarks;
        obtainedMarksSum += obtainedMarks;
    }

    let percentage = (obtainedMarksSum / totalMarksSum) * 100;
    let grade = percentage >= 80 ? 'A' : percentage >= 70 ? 'B' : percentage >= 60 ? 'C' : percentage >= 50 ? 'D' : 'F (Fail)';

    document.getElementById("marksOutput").innerHTML = `
        <strong>Total Marks:</strong> ${totalMarksSum} <br>
        <strong>Obtained Marks:</strong> ${obtainedMarksSum} <br>
        <strong>Overall Percentage:</strong> ${percentage.toFixed(2)}% <br>
        <strong>Final Grade:</strong> ${grade}
    `;
}

// Function to generate input fields for GPA calculation
function generateGPAInputs() {
    let totalCourses = document.getElementById("totalCourses").value;
    let gpaInputs = document.getElementById("gpaInputs");
    gpaInputs.innerHTML = "";

    for (let i = 0; i < totalCourses; i++) {
        gpaInputs.innerHTML += `
            <h4>Course ${i + 1}</h4>
            <select id="grade${i}">
                <option value="4">A (4.0)</option>
                <option value="3.7">A- (3.7)</option>
                <option value="3.3">B+ (3.3)</option>
                <option value="3.0">B (3.0)</option>
                <option value="2.7">B- (2.7)</option>
                <option value="2.3">C+ (2.3)</option>
                <option value="2.0">C (2.0)</option>
                <option value="1.7">C- (1.7)</option>
                <option value="1.3">D+ (1.3)</option>
                <option value="1.0">D (1.0)</option>
                <option value="0">F (0.0)</option>
            </select>
            <input type="number" id="credit${i}" placeholder="Credit Hours" />
        `;
    }
}

// Function to calculate GPA
function calculateGPA() {
    let totalCourses = document.getElementById("totalCourses").value;
    let totalCredits = 0, totalGradePoints = 0;

    for (let i = 0; i < totalCourses; i++) {
        let grade = parseFloat(document.getElementById(`grade${i}`).value);
        let credit = parseFloat(document.getElementById(`credit${i}`).value) || 0;

        totalGradePoints += grade * credit;
        totalCredits += credit;
    }

    let finalGPA = totalGradePoints / totalCredits || 0;

    document.getElementById("gpaOutput").innerHTML = `
        <strong>Total Credits:</strong> ${totalCredits} <br>
        <strong>Final GPA:</strong> ${finalGPA.toFixed(2)}
    `;
}

// Light & Dark Mode Functions
function setLightMode() {
    document.body.classList.remove("dark-mode");
}

function setDarkMode() {
    document.body.classList.add("dark-mode");
}
