function getRandomNumber(max) {
    return Math.floor(Math.random() * max) + 1;
}

function generateQuestion() {
    const num1 = getRandomNumber(10);
    const num2 = getRandomNumber(10);
    const operations = ['+', '-', '*', '/'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    let correctAnswer;
    
    switch (operation) {
        case '+': correctAnswer = num1 + num2; break;
        case '-': correctAnswer = num1 - num2; break;
        case '*': correctAnswer = num1 * num2; break;
        case '/': correctAnswer = (num1 / num2).toFixed(2); break;
    }
    
    document.getElementById("question").innerText = `What is ${num1} ${operation} ${num2}?`;
    
    const options = new Set();
    options.add(correctAnswer);
    while (options.size < 4) {
        options.add(getRandomNumber(20));
    }
    
    const optionsArray = [...options].sort(() => Math.random() - 0.5);
    
    const optionsDiv = document.getElementById("options");
    optionsDiv.innerHTML = "";
    optionsArray.forEach(option => {
        const btn = document.createElement("button");
        btn.innerText = option;
        btn.onclick = () => checkAnswer(option, correctAnswer);
        optionsDiv.appendChild(btn);
    });
    
    document.getElementById("result").innerText = "";
}

function checkAnswer(selected, correct) {
    if (selected == correct) {
        document.getElementById("result").innerText = "Correct! 🎉";
        document.getElementById("result").style.color = "green";
    } else {
        document.getElementById("result").innerText = "Wrong! ❌";
        document.getElementById("result").style.color = "red";
    }
}

generateQuestion();
