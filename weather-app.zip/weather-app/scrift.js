const apiKey = "5e3079de36eac4278824ff08374bde54";

async function getWeather() {
    const city = document.getElementById("cityInput").value;

    if (!city) {
        alert("Please enter a city name");
        return;
    }

    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

    try {
        const response = await fetch(url);
        const data = await response.json(); // Fixed 'json()' spelling

        if (data.cod !== 200) {
            alert("City not found");
            return;
        }

        // Fixed element IDs and typos
        document.getElementById("cityName").innerText = `Weather in ${data.name}`;
        document.getElementById("temperature").innerText = `Temperature: ${data.main.temp}°C`;
        document.getElementById("description").innerText = `Condition: ${data.weather[0].description}`;
        document.getElementById("humidity").innerText = `Humidity: ${data.main.humidity}%`;
        document.getElementById("windSpeed").innerText = `Wind Speed: ${data.wind.speed} m/s`;

        document.getElementById("weatherResult").style.display = "block";

    } catch (error) {
        console.error("Error fetching weather data:", error);
        alert("An error occurred while fetching weather data");
    }
}
